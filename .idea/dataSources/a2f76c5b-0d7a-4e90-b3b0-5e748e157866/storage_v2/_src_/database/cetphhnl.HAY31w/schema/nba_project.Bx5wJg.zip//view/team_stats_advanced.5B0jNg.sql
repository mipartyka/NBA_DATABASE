create view team_stats_advanced
            (id_team_stats, pts, trb, ast, stl, blk, fg, fga, fg_pct, fg3, fg3a, fg3_pct, ft, fta, ft_pct, orb, drb,
             tov, true_shooting_pct, "2p", "2pa", "2p_pct", efg_pct)
as
SELECT team_stats.id_team_stats,
       team_stats.pts,
       team_stats.trb,
       team_stats.ast,
       team_stats.stl,
       team_stats.blk,
       team_stats.fg,
       team_stats.fga,
       team_stats.fg_pct,
       team_stats.fg3,
       team_stats.fg3a,
       team_stats.fg3_pct,
       team_stats.ft,
       team_stats.fta,
       team_stats.ft_pct,
       team_stats.orb,
       team_stats.drb,
       team_stats.tov,
       round(team_stats.pts /
             (2::double precision * (team_stats.fga + 0.44::double precision * team_stats.fta))) AS true_shooting_pct,
       team_stats.fg - team_stats.fg3                                                            AS "2p",
       team_stats.fga - team_stats.fg3a                                                          AS "2pa",
       CASE
           WHEN (team_stats.fga - team_stats.fg3a) > 0::double precision
               THEN round((team_stats.fg - team_stats.fg3) / (team_stats.fga - team_stats.fg3a))
           ELSE NULL::double precision
           END                                                                                   AS "2p_pct",
       round((team_stats.fg + 0.5::double precision * team_stats.fg3) / team_stats.fga)          AS efg_pct
FROM nba_project.team_stats;

alter table team_stats_advanced
    owner to cetphhnl;

