create function update_team_game_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Insert new records
    INSERT INTO team_game (id_game, id_team, pts, trb, ast, stl, fg, fga, fg_pct, fg3, fg3a, fg3_pct, ft, fta, ft_pct, orb, drb, tov, blk)
    SELECT
        NEW.id_game,
        p.id_team,
        SUM(pg.pts),
        SUM(pg.trb),
        SUM(pg.ast),
        SUM(pg.stl),
        SUM(pg.fg),
        SUM(pg.fga),
        CASE WHEN COUNT(*) > 0 THEN SUM(pg.fg_pct) / COUNT(*) ELSE 0 END,
        SUM(pg.fg3),
        SUM(pg.fg3a),
        CASE WHEN COUNT(*) > 0 THEN SUM(pg.fg3_pct) / COUNT(*) ELSE 0 END,
        SUM(pg.ft),
        SUM(pg.fta),
        CASE WHEN COUNT(*) > 0 THEN SUM(pg.ft_pct) / COUNT(*) ELSE 0 END,
        SUM(pg.orb),
        SUM(pg.drb),
        SUM(pg.tov),
        SUM(pg.blk)
    FROM
        player_game pg
            JOIN player p ON pg.id_player = p.id_player
    WHERE
            pg.id_game = NEW.id_game AND
            p.id_team = NEW.id_team;

    RETURN NULL; -- No need to return anything for an AFTER UPDATE trigger
END;
$$;

alter function update_team_game_trigger() owner to cetphhnl;

