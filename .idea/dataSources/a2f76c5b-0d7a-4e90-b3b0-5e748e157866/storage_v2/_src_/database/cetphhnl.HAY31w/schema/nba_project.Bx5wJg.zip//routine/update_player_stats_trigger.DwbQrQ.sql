create function update_player_stats_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE player_stats
    SET
        games = (SELECT COUNT(*) FROM player_game WHERE id_player = NEW.id_player),
        pts = (SELECT AVG(pts) FROM player_game WHERE id_player = NEW.id_player),
        trb = (SELECT AVG(trb) FROM player_game WHERE id_player = NEW.id_player),
        ast = (SELECT AVG(ast) FROM player_game WHERE id_player = NEW.id_player),
        stl = (SELECT AVG(stl) FROM player_game WHERE id_player = NEW.id_player),
        mp = (SELECT AVG(mp) FROM player_game WHERE id_player = NEW.id_player),
        pf = (SELECT AVG(pf) FROM player_game WHERE id_player = NEW.id_player),
        fg = (SELECT AVG(fg) FROM player_game WHERE id_player = NEW.id_player),
        fga = (SELECT AVG(fga) FROM player_game WHERE id_player = NEW.id_player),
        fg_pct = (SELECT CASE WHEN AVG(fga) = 0 THEN NULL ELSE CAST(AVG(fg) AS double precision)/AVG(fga) END FROM player_game WHERE id_player = NEW.id_player),
        fg3 = (SELECT AVG(fg3) FROM player_game WHERE id_player = NEW.id_player),
        fg3a = (SELECT AVG(fg3a) FROM player_game WHERE id_player = NEW.id_player),
        fg3_pct = (SELECT CASE WHEN AVG(fg3a) = 0 THEN NULL ELSE CAST(AVG(fg3) AS double precision)/AVG(fg3a) END FROM player_game WHERE id_player = NEW.id_player),
        ft = (SELECT AVG(ft) FROM player_game WHERE id_player = NEW.id_player),
        fta = (SELECT AVG(fta) FROM player_game WHERE id_player = NEW.id_player),
        ft_pct = (SELECT CASE WHEN AVG(fta) = 0 THEN NULL ELSE CAST(AVG(ft) AS double precision)/AVG(fta) END FROM player_game WHERE id_player = NEW.id_player),
        orb = (SELECT AVG(orb) FROM player_game WHERE id_player = NEW.id_player),
        drb = (SELECT AVG(drb) FROM player_game WHERE id_player = NEW.id_player),
        tov = (SELECT AVG(tov) FROM player_game WHERE id_player = NEW.id_player),
        blk = (SELECT AVG(blk) FROM player_game WHERE id_player = NEW.id_player),
        plus_minus = (SELECT AVG(plus_minus) FROM player_game WHERE id_player = NEW.id_player)
    WHERE id_player_stats = NEW.id_player;

    RETURN NEW;
END;
$$;

alter function update_player_stats_trigger() owner to cetphhnl;

