create function getplayerboxscore(p_id_game character varying, p_id_team integer)
    returns TABLE(player_id integer, name character varying, surname character varying, pts integer, trb integer, ast integer, stl integer, blk integer, fg integer, fga integer, fg_pct double precision, fg3 integer, fg3a integer, fg3_pct double precision, ft integer, fta integer, ft_pct double precision, orb integer, drb integer, tov integer, plus_minus integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
        pg.id_player,
        p.name ,
        p.surname,
        pg.pts,
        pg.trb,
        pg.ast,
        pg.stl,
        pg.blk,  -- Added blk for player
        pg.fg,
        pg.fga,
        pg.fg_pct,
        pg.fg3,
        pg.fg3a,
        pg.fg3_pct,
        pg.ft,
        pg.fta,
        pg.ft_pct,
        pg.orb,
        pg.drb,
        pg.tov AS tov,
        pg.plus_minus  -- Added plus_minus for player
        FROM
            player_game pg
                INNER JOIN player p ON pg.id_player = p.id_player
                INNER JOIN team_game tg ON pg.id_game = tg.id_game AND pg.id_team = tg.id_team
                INNER JOIN team t ON tg.id_team = t.id_team
        WHERE
                pg.id_game = p_id_game
          AND (p_id_team IS NULL OR pg.id_team = p_id_team) -- Filter based on p_id_team if not NULL
        ORDER BY
            pg.id_team, pg.pts DESC NULLS LAST;
END;
$$;

alter function getplayerboxscore(varchar, integer) owner to cetphhnl;

