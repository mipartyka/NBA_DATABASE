create function get_user_by_login(p_login character varying)
    returns TABLE(id_user integer, login character varying, password character varying, role character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT u.id_user, u.login, u.password, u.role
        FROM "user" u
        WHERE u.login = p_login;
END;
$$;

alter function get_user_by_login(varchar) owner to cetphhnl;

