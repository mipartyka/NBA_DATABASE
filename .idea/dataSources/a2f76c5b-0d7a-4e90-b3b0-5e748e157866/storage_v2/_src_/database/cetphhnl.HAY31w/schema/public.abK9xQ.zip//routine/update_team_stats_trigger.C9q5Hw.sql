create function update_team_stats_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE team_stats
    SET
        pts = (SELECT AVG(pts) FROM team_game WHERE id_team = NEW.id_team),
        trb = (SELECT AVG(trb) FROM team_game WHERE id_team = NEW.id_team),
        ast = (SELECT AVG(ast) FROM team_game WHERE id_team = NEW.id_team),
        stl = (SELECT AVG(stl) FROM team_game WHERE id_team = NEW.id_team),
        fg = (SELECT AVG(fg) FROM team_game WHERE id_team = NEW.id_team),
        fga = (SELECT AVG(fga) FROM team_game WHERE id_team = NEW.id_team),
        fg_pct = (SELECT CASE WHEN AVG(fga) = 0 THEN NULL ELSE AVG(fg)/AVG(fga) END FROM team_game WHERE id_team = NEW.id_team),
        fg3 = (SELECT AVG(fg3) FROM team_game WHERE id_team = NEW.id_team),
        fg3a = (SELECT AVG(fg3a) FROM team_game WHERE id_team = NEW.id_team),
        fg3_pct = (SELECT CASE WHEN AVG(fg3a) = 0 THEN NULL ELSE AVG(fg3)/AVG(fg3a) END FROM team_game WHERE id_team = NEW.id_team),
        ft = (SELECT AVG(ft) FROM team_game WHERE id_team = NEW.id_team),
        fta = (SELECT AVG(fta) FROM team_game WHERE id_team = NEW.id_team),
        ft_pct = (SELECT CASE WHEN AVG(fta) = 0 THEN NULL ELSE AVG(ft)/AVG(fta) END FROM team_game WHERE id_team = NEW.id_team),
        orb = (SELECT AVG(orb) FROM team_game WHERE id_team = NEW.id_team),
        drb = (SELECT AVG(drb) FROM team_game WHERE id_team = NEW.id_team),
        tov = (SELECT AVG(tov) FROM team_game WHERE id_team = NEW.id_team),
        blk = (SELECT AVG(blk) FROM team_game WHERE id_team = NEW.id_team)
    WHERE id_team_stats = NEW.id_team;
    RETURN NEW;
END;
$$;

alter function update_team_stats_trigger() owner to cetphhnl;

