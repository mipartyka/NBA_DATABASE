create view player_stats_advanced
            (id_player_stats, games, pts, trb, ast, stl, blk, mp, pf, fg, fga, fg_pct, fg3, fg3a, fg3_pct, ft, fta,
             ft_pct, orb, drb, tov, personal_fouls, plus_minus, true_shooting_pct, "2p", "2pa", "2p_pct", efg_pct)
as
SELECT player_stats.id_player_stats,
       player_stats.games,
       player_stats.pts,
       player_stats.trb,
       player_stats.ast,
       player_stats.stl,
       player_stats.blk,
       player_stats.mp,
       player_stats.pf,
       player_stats.fg,
       player_stats.fga,
       player_stats.fg_pct,
       player_stats.fg3,
       player_stats.fg3a,
       player_stats.fg3_pct,
       player_stats.ft,
       player_stats.fta,
       player_stats.ft_pct,
       player_stats.orb,
       player_stats.drb,
       player_stats.tov,
       player_stats.pf                                                                               AS personal_fouls,
       player_stats.plus_minus,
       round(player_stats.pts / (2::double precision *
                                 (player_stats.fga + 0.44::double precision * player_stats.fta)))    AS true_shooting_pct,
       player_stats.fg - player_stats.fg3                                                            AS "2p",
       player_stats.fga - player_stats.fg3a                                                          AS "2pa",
       CASE
           WHEN (player_stats.fga - player_stats.fg3a) > 0::double precision THEN round(
                       (player_stats.fg - player_stats.fg3) / (player_stats.fga - player_stats.fg3a))
           ELSE NULL::double precision
           END                                                                                       AS "2p_pct",
       round((player_stats.fg + 0.5::double precision * player_stats.fg3) / player_stats.fga)        AS efg_pct
FROM nba_project.player_stats;

alter table player_stats_advanced
    owner to cetphhnl;

