create function update_team_game_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Check if a record for the same game and team already exists
    IF EXISTS (
        SELECT 1 
        FROM team_game 
        WHERE id_game = NEW.id_game AND id_team = NEW.id_team
    ) THEN
        -- Update existing record
        UPDATE team_game
        SET
            pts = subquery.pts,
            trb = subquery.trb,
            ast = subquery.ast,
            stl = subquery.stl,
            fg = subquery.fg,
            fga = subquery.fga,
            fg_pct = subquery.fg_pct,
            fg3 = subquery.fg3,
            fg3a = subquery.fg3a,
            fg3_pct = subquery.fg3_pct,
            ft = subquery.ft,
            fta = subquery.fta,
            ft_pct = subquery.ft_pct,
            orb = subquery.orb,
            drb = subquery.drb,
            tov = subquery.tov,
            blk = subquery.blk
        FROM (
            SELECT
                SUM(pts) AS pts,
                SUM(trb) AS trb,
                SUM(ast) AS ast,
                SUM(stl) AS stl,
                SUM(fg) AS fg,
                SUM(fga) AS fga,
                CASE WHEN COUNT(*) > 0 THEN SUM(fg_pct) / COUNT(*) ELSE 0 END AS fg_pct,
                SUM(fg3) AS fg3,
                SUM(fg3a) AS fg3a,
                CASE WHEN COUNT(*) > 0 THEN SUM(fg3_pct) / COUNT(*) ELSE 0 END AS fg3_pct,
                SUM(ft) AS ft,
                SUM(fta) AS fta,
                CASE WHEN COUNT(*) > 0 THEN SUM(ft_pct) / COUNT(*) ELSE 0 END AS ft_pct,
                SUM(orb) AS orb,
                SUM(drb) AS drb,
                SUM(tov) AS tov,
                SUM(blk) AS blk
            FROM player_game
            WHERE
                id_game = NEW.id_game AND
                id_team = NEW.id_team
        ) AS subquery
        WHERE
            id_game = NEW.id_game AND
            id_team = NEW.id_team;
    ELSE
        -- Insert new record
        INSERT INTO team_game (id_game, id_team, pts, trb, ast, stl, fg, fga, fg_pct, fg3, fg3a, fg3_pct, ft, fta, ft_pct, orb, drb, tov, blk)
        SELECT
            NEW.id_game,
            NEW.id_team,
            SUM(pts),
            SUM(trb),
            SUM(ast),
            SUM(stl),
            SUM(fg),
            SUM(fga),
            CASE WHEN COUNT(*) > 0 THEN SUM(fg_pct) / COUNT(*) ELSE 0 END,
            SUM(fg3),
            SUM(fg3a),
            CASE WHEN COUNT(*) > 0 THEN SUM(fg3_pct) / COUNT(*) ELSE 0 END,
            SUM(ft),
            SUM(fta),
            CASE WHEN COUNT(*) > 0 THEN SUM(ft_pct) / COUNT(*) ELSE 0 END,
            SUM(orb),
            SUM(drb),
            SUM(tov),
            SUM(blk)
        FROM player_game
        WHERE
            id_game = NEW.id_game AND
            id_team = NEW.id_team;
    END IF;

    RETURN NULL; -- No need to return anything for an AFTER UPDATE trigger
END;
$$;

alter function update_team_game_trigger() owner to cetphhnl;

