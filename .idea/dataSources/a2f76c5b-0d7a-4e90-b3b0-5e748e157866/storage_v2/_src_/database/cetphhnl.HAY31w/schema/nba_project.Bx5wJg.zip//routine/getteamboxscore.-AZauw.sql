create function getteamboxscore(p_id_game character varying, p_id_team integer)
    returns TABLE(team_id integer, team_name character varying, team_pts integer, team_trb integer, team_ast integer, team_stl integer, team_blk integer, team_fg integer, team_fga integer, team_fg_pct double precision, team_fg3 integer, team_fg3a integer, team_fg3_pct double precision, team_ft integer, team_fta integer, team_ft_pct double precision, team_orb integer, team_drb integer, team_tov integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
        tg.id_team,
        t.name AS team_name,
        tg.pts AS team_pts,
        tg.trb AS team_trb,
        tg.ast AS team_ast,
        tg.stl AS team_stl,
        tg.blk AS team_blk,  -- Added blk for team
        tg.fg AS team_fg,
        tg.fga AS team_fga,
        tg.fg_pct AS team_fg_pct,
        tg.fg3 AS team_fg3,
        tg.fg3a AS team_fg3a,
        tg.fg3_pct AS team_fg3_pct,
        tg.ft AS team_ft,
        tg.fta AS team_fta,
        tg.ft_pct AS team_ft_pct,
        tg.orb AS team_orb,
        tg.drb AS team_drb,
        tg.tov AS team_tov
        FROM
            team_game tg
                INNER JOIN team t ON tg.id_team = t.id_team
        WHERE
                tg.id_game = p_id_game
          AND (p_id_team IS NULL OR tg.id_team = p_id_team) -- Filter based on p_id_team if not NULL
        ORDER BY
            tg.id_team;
END;
$$;

alter function getteamboxscore(varchar, integer) owner to cetphhnl;

