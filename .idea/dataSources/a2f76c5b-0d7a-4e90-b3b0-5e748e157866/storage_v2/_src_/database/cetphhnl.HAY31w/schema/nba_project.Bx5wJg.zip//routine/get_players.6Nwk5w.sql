create function get_players()
    returns TABLE(id_player integer, name character varying, surname character varying, pos character varying, team character varying, games integer, pts double precision, trb double precision, ast double precision, stl double precision, blk double precision, minutes time without time zone, fg_made double precision, fg_attempted double precision, fg_percentage double precision, three_p_made double precision, three_p_attempted double precision, three_p_percentage double precision, ft_made double precision, ft_attempted double precision, ft_percentage double precision, off_rebounds double precision, def_rebounds double precision, turnovers double precision, fouls double precision, plus_minus double precision)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            p.id_player,
            p.name,
            p.surname,
            p.position as pos,
            CASE WHEN p.id_team IS NOT NULL THEN t.name ELSE NULL END AS team,
            ps.games,
            ps.pts,
            ps.trb,
            ps.ast,
            ps.stl,
            ps.blk,
            ps.mp AS minutes,
            ps.fg AS fg_made,
            ps.fga AS fg_attempted,
            ps.fg_pct AS fg_percentage,
            ps.fg3 AS three_p_made,
            ps.fg3a AS three_p_attempted,
            ps.fg3_pct AS three_p_percentage,
            ps.ft AS ft_made,
            ps.fta AS ft_attempted,
            ps.ft_pct AS ft_percentage,
            ps.orb AS off_rebounds,
            ps.drb AS def_rebounds,
            ps.tov,
            ps.pf AS fouls,
            ps.plus_minus
        FROM
            player p
                JOIN
            player_stats ps ON p.id_player_stats = ps.id_player_stats
                LEFT JOIN
            team t ON p.id_team = t.id_team
        ORDER BY p.id_player ;
END;
$$;

alter function get_players() owner to cetphhnl;

