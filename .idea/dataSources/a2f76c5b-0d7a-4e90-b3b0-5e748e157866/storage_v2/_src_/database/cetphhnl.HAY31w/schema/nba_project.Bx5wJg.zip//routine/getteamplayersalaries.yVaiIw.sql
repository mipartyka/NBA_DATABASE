create function getteamplayersalaries(p_team_id integer)
    returns TABLE(player_id integer, name character varying, surname character varying, salary numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            p.id_player,
            p.name,
            p.surname,
            COALESCE(SUM(cy.money), 0.00) AS salary
        FROM
            player p
                INNER JOIN player_contract pc ON p.id_contract = pc.id_contract
                LEFT JOIN contract_year cy ON pc.id_contract = cy.id_contract
        WHERE
                p.id_team = p_team_id
          AND cy.year = '2023-24'
        GROUP BY
            p.id_player, p.name, p.surname;
END;
$$;

alter function getteamplayersalaries(integer) owner to cetphhnl;

