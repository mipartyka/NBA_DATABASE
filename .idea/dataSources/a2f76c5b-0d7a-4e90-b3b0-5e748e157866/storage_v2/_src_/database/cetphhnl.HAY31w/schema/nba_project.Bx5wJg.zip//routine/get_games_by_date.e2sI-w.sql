create function get_games_by_date(target_date character varying)
    returns TABLE(id_game character varying, home_team integer, away_team integer, date date, type character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            g.id_game as id_game,
            g.id_home_team as home_team,
            g.id_away_team as away_team,
            g.game_date as gdate,
            g.game_type as type
        FROM
            game g
        WHERE
                g.game_date = target_date::DATE;
END;
$$;

alter function get_games_by_date(varchar) owner to cetphhnl;

