create function get_games_by_date(target_date character varying)
    returns TABLE(id_game character varying, home_team character varying, away_team character varying, date date, type character varying, home_team_points bigint, away_team_points bigint, id_home_team integer, id_away_team integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            g.id_game as id_game,
            home.name as home_team,
            away.name as away_team,
            g.game_date as gdate,
            g.game_type as type,
            COALESCE(SUM(tg_home.pts), 0) as home_team_points,
            COALESCE(SUM(tg_away.pts), 0) as away_team_points,
            g.id_home_team as id_home_team,
            g.id_away_team as id_away_team
        FROM
            game g
                LEFT JOIN team_game tg_home ON g.id_game = tg_home.id_game AND g.id_home_team = tg_home.id_team
                LEFT JOIN team_game tg_away ON g.id_game = tg_away.id_game AND g.id_away_team = tg_away.id_team
                LEFT JOIN team home ON g.id_home_team = home.id_team
                LEFT JOIN team away ON g.id_away_team = away.id_team
        WHERE
                g.game_date = target_date::DATE
        GROUP BY
            g.id_game, home.name, away.name, g.game_date, g.game_type, g.id_home_team, g.id_away_team;
END;
$$;

alter function get_games_by_date(varchar) owner to cetphhnl;

