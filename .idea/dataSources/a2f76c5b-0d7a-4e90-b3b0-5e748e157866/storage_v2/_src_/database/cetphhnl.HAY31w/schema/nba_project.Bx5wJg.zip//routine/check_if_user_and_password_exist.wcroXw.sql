create function check_if_user_and_password_exist(p_login character varying, p_password character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    user_exists BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1
        FROM "user"
        WHERE login = p_login AND password = p_password
    ) INTO user_exists;

    RETURN user_exists;
END;
$$;

alter function check_if_user_and_password_exist(varchar, varchar) owner to cetphhnl;

