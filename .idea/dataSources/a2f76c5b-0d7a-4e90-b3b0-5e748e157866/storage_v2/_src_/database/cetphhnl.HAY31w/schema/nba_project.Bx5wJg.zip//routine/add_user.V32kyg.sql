create function add_user(p_login character varying, p_password character varying, p_role character varying) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO "user" (login, password, role)
    VALUES (p_login, p_password, p_role);
END;
$$;

alter function add_user(varchar, varchar, varchar) owner to cetphhnl;

