create function getteamsalaries(p_team_id integer)
    returns TABLE(team_id integer, team_name character varying, total_salary numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        t.id_team,
        t.name AS team_name,
        COALESCE(SUM(cy.money), 0.00) AS total_salary
    FROM
        team t
    LEFT JOIN player p ON t.id_team = p.id_team
    LEFT JOIN player_contract pc ON p.id_contract = pc.id_contract
    LEFT JOIN contract_year cy ON pc.id_contract = cy.id_contract
    WHERE
        t.id_team = p_team_id
        AND cy.year = '2023-24'
    GROUP BY
        t.id_team, t.name;
END;
$$;

alter function getteamsalaries(integer) owner to cetphhnl;

